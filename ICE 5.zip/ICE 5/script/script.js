//Name: Princess Emmanuel
//Description: JQuery script
//Date: 21st February 2024


$(document).ready(function () {
    console.log("jQuery is running!");
    // Injecting an H1 header into the header HTML element with an id of "header"
    $("#header").html("<h1>Welcome to our Travel Blog!</h1>");
  
    // Create Navigation Bar
    const categories = ["Beaches", "Mountains", "Cities", "Forests", "Deserts"];
    let navContent = "<ul>";
    $.each(categories, function (index, category) {
      // console.log(index);
      // console.log(category);
      navContent += `<li onclick="loadCategoryContent('${category}')">${category}</li>`;
    });
    navContent += "</ul>";
    $("#navbar").html(navContent);
  
    window.loadCategoryContent = function (category) {
      console.log("loadCategoryContent function ran!");
      console.log(category);
      let content = `<h2>${category}</h2>`;
      content += `<div class="carousel" id="${category.toLowerCase()}-carousel"></div>`;
      $("#content").html(content);
  
      populateCarousel(category.toLowerCase());
    };
  
    const categoryImages = {
      beaches: [
        { alt: "Beach Sunset", src: "beach1.jpg" },
        { alt: "Sandy Shore", src: "beach2.jpg" },
        { alt: "Marina Resort", src: "beach3.jpg" },
      ],
      mountains: [
        { alt: "Mountain Range", src: "mountain1.jpg" },
        { alt: "Snowy Peak", src: "mountain2.jpg" },
        { alt: "Hiking Trail", src: "mountain3.jpg" },
      ],
      cities: [
        { alt: "Cityscape", src: "city1.jpg" },
        { alt: "Downtown", src: "city2.jpg" },
        { alt: "Urban Skyline", src: "city3.jpg" },
      ],
      forests: [
        { alt: "Forest Path", src: "forest1.jpg" },
        { alt: "Misty Woods", src: "forest2.jpg" },
        { alt: "Redwood Forest", src: "forest3.jpg" },
      ],
      deserts: [
        { alt: "Sand Dunes", src: "desert1.jpg" },
        { alt: "Desert Oasis", src: "desert2.jpg" },
        { alt: "Rocky Desert", src: "desert3.jpg" },
      ],
    };
    // category = beaches
    function populateCarousel(category) {
      console.log("populate carousel ran!");
      const images = categoryImages[category];
  
      // [].forEach(), [].map() -> 2 Array Iterator Method
      let carouselContent = images
        .map((image, index) => {
          return `<div class="carousel-item ${index == 0 ? "active" : ""}">
        <div class="image" style="background-image: url('${image.src}')">
        </div>
        <p>${image.alt}</p>
        </div>
        `;
        })
        .join("");
  
      $(`#${category}-carousel`).html(carouselContent);
  
      $(`#${category}-carousel`).append(`
      <button class="carousel-control prev" onclick="moveCarousel('${category}', -1)">&lt;</button>
      <button class="carousel-control next" onclick="moveCarousel('${category}', 1)">&gt;</button>
      `);
    }
  
    window.moveCarousel = function (category, direction) {
      debugger;
      let items = $(`#${category}-carousel .carousel-item`);
  
      let activeIndex = items.index(items.filter(".active"));
  
      let newIndex = activeIndex + direction;
  
      if (newIndex >= items.length) {
        newIndex = 0;
      } else if (newIndex < 0) {
        newIndex = items.length - 1;
      }
      items.removeClass("active");
      items.eq(newIndex).addClass("active");
    };
  });
  
  // ICE 5 Tasks:
  // 1.Populate Cities, Forests & Deserts
  // 2. Add 3 images to the Cities & Deserts (Optionally, you may add images for the rest of the categories)
  // 3. Dynamically add content to the Footer using jQuery. The content should include a short description of your favorite category/place and why.
  const favoritePlaces = {
    beaches: "Coastal areas where land meets the sea/ocean, sandy or rocky. Types include sandy beaches, rocky beaches, coral beaches.",
    mountains: "Elevated landforms with steep slopes and high peaks. Types include fold mountains (e.g., the Alps), volcanic mountains (e.g., Mount Fuji), block mountains (e.g., the Sierra Nevada).",
    cities: "Urban areas with high population density and cultural/economic activities. Types include metropolises (e.g., New York City), megacities (e.g., Tokyo), historic cities (e.g., Rome).",
    forests: " Large areas covered chiefly with trees and undergrowth. Types include tropical rainforests (e.g., Amazon Rainforest), temperate forests (e.g., Black Forest), coniferous forests (e.g., Taiga).",
    deserts: "Arid regions with low precipitation and sparse vegetation. Types include hot deserts (e.g., Sahara Desert), cold deserts (e.g., Gobi Desert), coastal deserts (e.g., Atacama Desert)."
  };

  let footerContent = "<ul>";
  $.each(favoritePlaces, function (category, description) {
    footerContent += `<li><strong>${category}:</strong> ${description}</li>`;
  });
  footerContent += "</ul>";
  $("#footer").html(footerContent);

  