
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Get form values
    const name = document.getElementById('name').value;
    const contactNumber = document.getElementById('contactNumber').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Output values to console
    console.log("Name:", name);
    console.log("Contact Number:", contactNumber);
    console.log("Email:", email);
    console.log("Message:", message);

    // Redirect after 3 seconds
    setTimeout(function() {
        window.location.href = "index.html";
    }, 3000);
});
